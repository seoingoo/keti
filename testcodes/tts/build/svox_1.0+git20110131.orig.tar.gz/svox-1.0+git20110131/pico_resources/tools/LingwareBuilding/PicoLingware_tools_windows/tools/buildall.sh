rm ../pkb/*/*.pkb

./buildpkb.sh de DE gl0
./buildpkb.sh en GB kh0
./buildpkb.sh en US lh0
./buildpkb.sh es ES zl0
./buildpkb.sh fr FR nk0
./buildpkb.sh it IT cm0

./buildbin.sh de-DE gl0
./buildbin.sh en-GB kh0
./buildbin.sh en-US lh0
./buildbin.sh es-ES zl0
./buildbin.sh fr-FR nk0
./buildbin.sh it-IT cm0
